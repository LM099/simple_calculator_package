# Simple Calculator

Una semplice libreria Python che fornisce funzionalità di base per calcoli matematici.